#include <gtk/gtk.h>



void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_yes_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_no_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_annuler_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_button_affich_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_re_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_aff_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_login_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_restau_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_general_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_restau_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_general_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_general_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_restau_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button0_insc_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button0_auth_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rup_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview3_row_rup_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton_sup_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_image35_show                        (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview5_mod_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_rmod_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton_nv_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_anc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_rsup_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rrech_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_rnon_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_rrrch_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton2_nv_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_anc_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_rruptu_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_rajout_clicked              (GtkButton       *button,
                                        gpointer         user_data);
