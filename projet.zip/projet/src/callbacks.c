#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fon.h"


int x,y;
int l,t;

///////////////////Window Stock /////////////

///////Boutton Ajouter////////////
void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajou, *windowstock;
windowstock=lookup_widget(button,"window_stock");
gtk_widget_destroy(windowstock);
windowajou=create_window_ajouter();
gtk_widget_show (windowajou);

}
///////Boutton modifier////////////
void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmodif, *windowstock;
windowstock=lookup_widget(button,"window_stock");
gtk_widget_destroy(windowstock);
windowmodif=create_window_modifier();
gtk_widget_show (windowmodif);
}
///////Boutton Supprimer ////////////
void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowsupp, *windowstock;
windowstock=lookup_widget(button,"window_stock");
gtk_widget_destroy(windowstock);
windowsupp=create_window_supprimer();
gtk_widget_show (windowsupp);

}
///////Boutton Affichage ////////////
void
on_button_affich_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowstock;

windowstock=create_window_stock();
gtk_widget_show(windowstock);

tree=lookup_widget(windowstock,"treeview1");

affichageproduit(tree);

windowstock=lookup_widget(button,"window_stock");
gtk_widget_destroy(windowstock);
}
///////Boutton Rechercher ////////////
void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrechercher, *windowstock;
windowstock=lookup_widget(button,"window_stock");
gtk_widget_destroy(windowstock);
windowrechercher=create_window_rechercher();
gtk_widget_show(windowrechercher);
}
///////Boutton Rupture ////////////
void
on_button_rup_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
produit a;
GtkWidget *windowrupture, *windowstock;
GtkWidget *tree1;

windowstock=lookup_widget(button,"window_stock");
gtk_widget_destroy(windowstock);

a=rupturer();
windowrupture=create_window_rupture ();
tree1=lookup_widget(windowrupture,"treeview3");
affichageproduitrupturer(tree1);

gtk_widget_hide(windowrupture);
gtk_widget_show(windowrupture);

}

////////////////////////////////Window Ajouter /////////////////////////
void
on_button2_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
produit a;
GtkWidget *windowajout, *windowstock,*type,*id,*nom,*quantite,*jour,*mois,*annee,*choix,*etat;
windowajout=create_window_ajouter();
windowstock=create_window_stock();
id = lookup_widget(button,"entry1_iden");
nom = lookup_widget(button,"entry2_nom");
quantite = lookup_widget(button,"spinbutton1_quantite");
type=lookup_widget(button,"comboboxentry1_type");
jour = lookup_widget(button,"spinbutton1_date");
mois = lookup_widget(button,"spinbutton1_mois");
annee = lookup_widget(button,"spinbutton1_annee");
strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
a.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (quantite));
strcpy(a.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
if(x==1 )
{strcpy(a.choix,"general");} 
else
{strcpy(a.choix,"restaurant");}
if(l==1)
{strcpy(a.etat,"ancien");} 
else
{strcpy(a.etat,"nouveau");}
ajouterproduit(a);
x=0;
l=0;
windowajout=lookup_widget(button,"window_ajouter");
gtk_widget_destroy(windowajout);
windowstock=create_window_stock();
gtk_widget_show(windowstock);
}
///////////////Bouton radio ajouterr////////////////
void
on_radiobutton1_restau_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=0;}

}

void
on_radiobutton1_general_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}
//////////////////case a cocher ajouter ////////////
void
on_checkbutton_nv_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{l=0;}
}


void
on_checkbutton_anc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if(gtk_toggle_button_get_active((togglebutton)))
{l=1;}

}
//////////////////////////////Window Modifier ///////////////////////////////////

/////////////Bouton enregistrer modification /////////
void
on_button2_yes_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
produit a1;
GtkWidget *windowmodif, *windowstock, *id1, *nom1, *quant1,*type1,*jour1,*mois1,*annee1,*choix1,*etat1;
id1 = lookup_widget(button,"entry2_iden");
nom1 = lookup_widget(button,"entry2_nom");
quant1 = lookup_widget(button,"spinbutton2_quantite");
type1=lookup_widget(button,"comboboxentry2_type");
jour1 = lookup_widget(button,"spinbutton2_jour");
mois1 = lookup_widget(button,"spinbutton2_mois");
annee1 = lookup_widget(button,"spinbutton2_annee");
strcpy(a1.identifiant,gtk_entry_get_text(GTK_ENTRY(id1)));
strcpy(a1.nom,gtk_entry_get_text(GTK_ENTRY(nom1)));
a1.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (quant1));
strcpy(a1.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
a1.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
a1.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
a1.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
if(y==1 )
{strcpy(a1.choix,"restau");} 
else
{strcpy(a1.choix,"general");}
if(t==1)
{strcpy(a1.etat,"ancien");} 
else
{strcpy(a1.etat,"nouveau");}
modifierproduit(a1);
y=0;
t=0;

windowmodif=lookup_widget(button,"window_modifier");
gtk_widget_destroy(windowmodif);
windowstock=create_window_stock();
gtk_widget_show (windowstock);
}
/////////////Bouton retour modification /////////
void
on_button2_rmod_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmodif, *windowstock;
windowmodif=lookup_widget(button,"window_modifier");
gtk_widget_destroy(windowmodif);
windowstock=create_window_stock();
gtk_widget_show (windowstock);
}
/////////////Bouton Affichage modifier /////////
void
on_button_aff_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowmodif;

windowmodif=create_window_modifier();
gtk_widget_show(windowmodif);

tree=lookup_widget(windowmodif,"treeview5_mod");

affichageproduit(tree);

windowmodif=lookup_widget(button,"window_modifier");
gtk_widget_destroy(windowmodif);

}
//////////////////////////////Window Supprimer ///////////////////////////////////
void
on_button4_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
char identi[20];
GtkWidget *windowsup, *windowstock, *iden;
iden = lookup_widget(button,"entry3");
strcpy(identi,gtk_entry_get_text(GTK_ENTRY(iden)));
supprimerproduit(identi);

windowsup=lookup_widget(button,"window_supprimer");
gtk_widget_destroy(windowsup);
windowstock=create_window_stock();
gtk_widget_show(windowstock);
}
///////////////////Boutton Retour Supp/////////////////
void
on_button1_rsup_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowsup, *windowstock;
windowsup=lookup_widget(button,"window_supprimer");
gtk_widget_destroy(windowsup);
windowstock=create_window_stock();
gtk_widget_show (windowstock);
}
//////////////////////////////Treeview Affichage ///////////////////////////////////

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}
//////////////////////////////Window Rechercher ///////////////////////////////////
void
on_button_re_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
char identir[20];
GtkWidget *idenr, *rech,*o, *n;
GtkWidget *tree;
GtkWidget *windowrechercher;

int ce;
windowrechercher=lookup_widget(button,"window_rechercher");
o=create_recherche();
n=create_Introuvable();
idenr = lookup_widget(button,"entry_rech");
strcpy(identir,gtk_entry_get_text(GTK_ENTRY(idenr)));
ce=rechercherproduit(identir);
if (ce==0)
	{
		gtk_widget_show(n);
	}
if (ce==1)	
	{	

gtk_widget_destroy(windowrechercher);
tree=lookup_widget(o,"treeview4");

affichageproduitrechercher(tree);
gtk_widget_show(o);
}		
}
///////////////////Boutton Retour non/////////////////
void
on_button3_rnon_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *n, *windowstock;
n=lookup_widget(button,"create_Introuvable");
gtk_widget_destroy(n);
windowstock=create_window_stock();
gtk_widget_show (windowstock);
}
///////////////////Boutton Retour rechercher/////////////////
void
on_button_rrech_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrechercher, *windowstock;
windowrechercher=lookup_widget(button,"window_rechercher");
gtk_widget_destroy(windowrechercher);
windowstock=create_window_stock();
gtk_widget_show (windowstock);
}
///////////////////Boutton Retour aff rechercher/////////////////
void
on_button4_rrrch_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *o, *windowstock;
o=lookup_widget(button,"create_recherche");
gtk_widget_destroy(o);
windowstock=create_window_stock();
gtk_widget_show (windowstock);
}
//////////////////////////////Window Rupture ///////////////////////////////////
void
on_checkbutton_sup_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *windowrupture ;
GtkWidget *tree1;
remove("produitrupturer.txt");
windowrupture=create_window_rupture ();
tree1=lookup_widget(windowrupture,"treeview3");
affichageproduitrupturer(tree1);

gtk_widget_hide(windowrupture);
gtk_widget_show(windowrupture);

}

///////////////Bouton radio modifier////////////////
void
on_radiobutton_general_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
 {y=0;}
}

void
on_radiobutton_restau_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=1;}
}
//////////////////////////////Treeview Rupture ///////////////////////////////////
void
on_treeview3_row_rup_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


}
//////////////////////////////Treeview Rupture ///////////////////////////////////

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}

//////////////////////////////Treeview Modification ///////////////////////////////////
void
on_treeview5_mod_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}













void
on_checkbutton2_nv_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t=0;}
}


void
on_checkbutton2_anc_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t=1;}
}


void
on_button1_rruptu_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrupture, *windowstock;
windowrupture=lookup_widget(button,"window_rupture");
gtk_widget_destroy(windowrupture);
windowstock=create_window_stock();
gtk_widget_show (windowstock);
}


void
on_button2_rajout_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajout, *windowstock;
windowajout=lookup_widget(button,"window_ajouter");
gtk_widget_destroy(windowajout);
windowstock=create_window_stock();
gtk_widget_show (windowstock);
}

