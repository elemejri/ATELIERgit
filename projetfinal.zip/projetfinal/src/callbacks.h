#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modification_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_ident_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_modifierm_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouterm_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_meilleur_menu_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_affichagem_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ret_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ret1_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data);
