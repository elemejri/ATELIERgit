#include <gtk/gtk.h>


void
on_buttona_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonm_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonc_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_button_ajm_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttona_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonm_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaf_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
