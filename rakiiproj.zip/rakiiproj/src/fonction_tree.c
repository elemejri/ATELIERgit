#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "fonction.h"
#include "fonction_tree.h"


GtkListStore *store;

GtkTreeViewColumn *column;

GtkCellRenderer *render;

FILE *f;

void afficher_hebergements(GtkWidget *treeview){


	hebergement h;
	char date_entree[30];
	char date_sortie[30];
	char bloc[20];
	char niveau[20];



       
        store = gtk_list_store_new(7,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING);
        
        f=fopen("hebergement.txt","r");
	while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d %s \n", h.id, h.nom, h.prenom, &h.date_entree.jour, &h.date_entree.mois, &h.date_entree.annee, &h.date_sortie.jour, &h.date_sortie.mois, &h.date_sortie.annee, &h.niveau, h.bloc)!=EOF){
		
		GtkTreeIter iter;
		strcpy(bloc,"Bloc ");
		strcat(bloc,h.bloc);
		sprintf(date_entree, "%d/%d/%d", h.date_entree.jour, h.date_entree.mois, h.date_entree.annee);
		sprintf(date_sortie, "%d/%d/%d", h.date_sortie.jour, h.date_sortie.mois, h.date_sortie.annee);

		sprintf(niveau,"Niveau %d",h.niveau);


         	
         	gtk_list_store_append(store, &iter);
         	
         	gtk_list_store_set(store, &iter, 0, h.id, 1,h.nom , 2, h.prenom, 3, date_entree, 4, date_sortie, 5, niveau, 6, bloc, -1);
	}
        fclose(f);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   ID",render, "text", 0, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   NOM",render, "text", 1, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);
	
	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   PRENOM",render, "text", 2, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   DATE ENTREE",render, "text", 3, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   DATE SORTIE",render, "text", 4, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   NIVEAU",render, "text", 5, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   BLOC",render, "text", 6, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);
	


 	gtk_tree_view_set_model(GTK_TREE_VIEW(treeview),GTK_TREE_MODEL(store));
}

void chercher_hebergement(GtkWidget *treeview, char *id){


	hebergement h;
	char date_entree[30];
	char date_sortie[30];
	char bloc[20];
	char niveau[20];



        
        store = gtk_list_store_new(7,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING,
				G_TYPE_STRING);
        
        f=fopen("hebergement.txt","r");
	while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d %s \n", h.id, h.nom, h.prenom, &h.date_entree.jour, &h.date_entree.mois, &h.date_entree.annee, &h.date_sortie.jour, &h.date_sortie.mois, &h.date_sortie.annee, &h.niveau, h.bloc)!=EOF){
		
		if(strcmp(id,h.id)==0){
			GtkTreeIter iter;
			strcpy(bloc,"Bloc ");
			strcpy(bloc,h.bloc);
			sprintf(date_entree, "%d/%d/%d", h.date_entree.jour, h.date_entree.mois, h.date_entree.annee);
			sprintf(date_sortie, "%d/%d/%d", h.date_sortie.jour, h.date_sortie.mois, h.date_sortie.annee);

			sprintf(niveau,"Niveau %d",h.niveau);


		 	
		 	gtk_list_store_append(store, &iter);
		 	
		 	gtk_list_store_set(store, &iter, 0, h.id, 1,h.nom , 2, h.prenom, 3, date_entree, 4, date_sortie, 5, niveau, 6, bloc, -1);
		}
	}
        fclose(f);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   ID",render, "text", 0, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   NOM",render, "text", 1, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);
	
	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   PRENOM",render, "text", 2, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   DATE ENTREE",render, "text", 3, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   DATE SORTIE",render, "text", 4, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   NIVEAU",render, "text", 5, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);

	render= gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("   BLOC",render, "text", 6, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),column);
	


 	gtk_tree_view_set_model(GTK_TREE_VIEW(treeview),GTK_TREE_MODEL(store));
}
