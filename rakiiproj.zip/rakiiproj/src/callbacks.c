#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "fonction.h"
#include "fonction_tree.h"
#include "support.h"

int niveau = 1;
int supp = 0;
int pass = 1;
int chercher = 1;


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	FILE *f= NULL;
	hebergement h;
	GtkWidget *window1;
	GtkWidget *window2;
	GtkWidget *treeview1;
	GtkWidget *treeview2;
	GtkWidget *combobox1;

	window1 = lookup_widget(button,"window1");
	window2 = create_window2();
	gtk_widget_hide(window1);
	gtk_widget_show(window2);

	treeview1 = lookup_widget(window2,"treeview1");
	treeview2 = lookup_widget(window2,"treeview2");
	combobox1 = lookup_widget(window2,"combobox1");

	afficher_hebergements(treeview1);
	afficher_hebergements(treeview2);

	f=fopen("hebergement.txt","r");

	while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d %s \n", h.id, h.nom, h.prenom, &h.date_entree.jour, &h.date_entree.mois, &h.date_entree.annee, &h.date_sortie.jour, &h.date_sortie.mois, &h.date_sortie.annee, &h.niveau, h.bloc)!=EOF){
		gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1),h.id);	
	}
	fclose(f);
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	hebergement h;
	GtkWidget *window2;
	GtkWidget *entry7;
	GtkWidget *entry8;
	GtkWidget *entry9;
	GtkWidget *calendar1;
	GtkWidget *calendar2;
	GtkWidget *comboboxentry1;
	GtkWidget *treeview1;
	GtkWidget *treeview2;
	GtkWidget *combobox1;

	GtkWidget *label_ajouter_reussite;
	GtkWidget *label37;
	GtkWidget *label38;
	GtkWidget *label39;


	window2 = lookup_widget(button,"window2");



	treeview1 = lookup_widget(window2,"treeview1");
	treeview2 = lookup_widget(window2,"treeview2");
	combobox1 = lookup_widget(window2,"combobox1");
	entry7 = lookup_widget(window2,"entry7");
	entry8 = lookup_widget(window2,"entry8");
	entry9 = lookup_widget(window2,"entry9");

	calendar1 = lookup_widget(window2,"calendar1");
	calendar2 = lookup_widget(window2,"calendar2");
	comboboxentry1 = lookup_widget(window2,"comboboxentry1");

	label_ajouter_reussite = lookup_widget(window2,"label_ajouter_reussite");
	label37 = lookup_widget(window2,"label37");
	label38 = lookup_widget(window2,"label38");
	label39 = lookup_widget(window2,"label39");


	strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(entry7)));
	strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(entry8)));
	strcpy(h.prenom,gtk_entry_get_text(GTK_ENTRY(entry9)));

	gtk_calendar_get_date(calendar1,&h.date_entree.annee,&h.date_entree.mois,&h.date_entree.jour);
	gtk_calendar_get_date(calendar2,&h.date_sortie.annee,&h.date_sortie.mois,&h.date_sortie.jour);

	strcpy(h.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)));


	h.niveau = niveau;

	gtk_widget_hide(label37);
	gtk_widget_hide(label38);
	gtk_widget_hide(label39);
	gtk_widget_hide(label_ajouter_reussite);

	if(strcmp(h.id,"") == 0){
		gtk_widget_show(label37);
		pass = 0;
	}
	if(strcmp(h.nom,"")==0){
		gtk_widget_show(label38);
		pass = 0;
	}
	if(strcmp(h.prenom,"")==0){
		gtk_widget_show(label39);
		pass = 0;
	}
	if(pass==1){
		ajouter_hebergement(h);
		gtk_widget_show(label_ajouter_reussite);
		gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1),h.id);
		afficher_hebergements(treeview1);
		afficher_hebergements(treeview2);
	}

}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *combobox1;
	GtkWidget *combobox2;
	GtkWidget *window2;
	GtkWidget *entry10;
	GtkWidget *entry11;
	GtkWidget *calendar3;
	GtkWidget *calendar4;
	GtkWidget *label46;
	GtkWidget *treeview1;
	GtkWidget *treeview2;
	GtkWidget *spinbutton_modifier;
	hebergement h;

	window2 = lookup_widget(button,"window2");
	treeview1 = lookup_widget(window2,"treeview1");
	treeview2 = lookup_widget(window2,"treeview2");
	combobox1 = lookup_widget(window2,"combobox1");
	combobox2 = lookup_widget(window2,"combobox2");
	entry10 = lookup_widget(window2,"entry10");
	entry11 = lookup_widget(window2,"entry11");
	calendar3 = lookup_widget(window2,"calendar3");
	calendar4 = lookup_widget(window2,"calendar4");
	label46 = lookup_widget(window2,"label46");

	spinbutton_modifier = lookup_widget(window2,"spinbutton_modifier");

	h = get_hebergement(gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	h.niveau = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_modifier));
	strcpy(h.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));

	if(strcmp(gtk_entry_get_text(GTK_ENTRY(entry10)),"")!=0){
		strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(entry10)));
	}

	if(strcmp(gtk_entry_get_text(GTK_ENTRY(entry11)),"")!=0){
		strcpy(h.prenom,gtk_entry_get_text(GTK_ENTRY(entry11)));
	}

	gtk_calendar_get_date(calendar3,&h.date_entree.annee,&h.date_entree.mois,&h.date_entree.jour);
	gtk_calendar_get_date(calendar4,&h.date_sortie.annee,&h.date_sortie.mois,&h.date_sortie.jour);

	modifier_hebergement(h);
	afficher_hebergements(treeview1);
	afficher_hebergements(treeview2);
	gtk_widget_show(label46);

	
	
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window2;
   	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* treeview1;
        GtkWidget *label_erreur_selection;
	char message_erreur[1000];

	window2 = lookup_widget(button,"window2");
        gchar* id;
        label_erreur_selection=lookup_widget(window2,"label_erreur_selection");
        treeview1=lookup_widget(window2,"treeview1");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
		if(supp == 0){
			gtk_label_set_text(label_erreur_selection,"Cocher la confirmation de supprission!");
	                gtk_widget_show (label_erreur_selection);
		} else if(supp == 1){
			gtk_tree_model_get (model,&iter,0,&id,-1);
			gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
			supprimer_hebergement(id);
			gtk_widget_hide (label_erreur_selection);
		}
	}else{
		gtk_label_set_text(label_erreur_selection,"Selectionner l'hebergement à supprimer!");
                gtk_widget_show (label_erreur_selection);
        }
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window2;
	GtkWidget *entry14;
	GtkWidget *treeview2;
	GtkWidget *label55;

	window2 = lookup_widget(button,"window2");
	entry14 = lookup_widget(window2,"entry14");
	treeview2  = lookup_widget(window2,"treeview2");
	label55  = lookup_widget(window2,"label55");

	gtk_widget_hide(label55);

	if(strcmp(gtk_entry_get_text(GTK_ENTRY(entry14)),"") == 0){
		gtk_widget_show(label55);
		chercher = 0;
	} else {
		chercher = 1;
	}

	if(chercher == 1){
		chercher_hebergement(treeview2, gtk_entry_get_text(GTK_ENTRY(entry14)));
	}
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;

	window2 = lookup_widget(button,"window2");
	window1 = create_window1();
	gtk_widget_hide(window2);
	gtk_widget_show(window1);
}




void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		niveau = 1;
	else
		niveau = 0;
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		niveau = 2;
	else
		niveau = 0;
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		niveau = 3;
	else
		niveau = 0;
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		supp = 1;
	else 
		supp = 0;
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	int e1 = 0;
	int e2 = 0;
	int e3 = 0;
        int e4 = 0;
        int e5 = 0;

	char e1_char[20];
	char e2_char[20];
	char e3_char[20];
        char e4_char[20];
        char e5_char[20];
	GtkWidget *window2;
	GtkWindow *label69;
	GtkWindow *label70;
	GtkWindow *label71;
        GtkWindow *label75;
        GtkWindow *label76;
	window2 = lookup_widget(button,"window2");
	label69 = lookup_widget(window2,"label69");
	label70 = lookup_widget(window2,"label70");
	label71 = lookup_widget(window2,"label71");
        label75 = lookup_widget(window2,"label75");
        label76 = lookup_widget(window2,"label76");

	e1 = nombre_etudiants_par_niveau(1);
	e2 = nombre_etudiants_par_niveau(2);
	e3 = nombre_etudiants_par_niveau(3);	
        e4 = nombre_etudiants_par_niveau(4);
        e5 = nombre_etudiants_par_niveau(5);

	sprintf(e1_char,"%d", e1);
	sprintf(e2_char,"%d", e2);
	sprintf(e3_char,"%d", e3);
        sprintf(e4_char,"%d", e4);
        sprintf(e5_char,"%d", e5);

	gtk_label_set_text(GTK_LABEL(label69),e1_char);
	gtk_widget_show(label69);
	gtk_label_set_text(GTK_LABEL(label70),e2_char);		
	gtk_widget_show(label70);				
	gtk_label_set_text(GTK_LABEL(label71),e3_char);
	gtk_widget_show(label71);
        gtk_label_set_text(GTK_LABEL(label75),e4_char);
	gtk_widget_show(label75);
        gtk_label_set_text(GTK_LABEL(label76),e5_char);
	gtk_widget_show(label76);							
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		niveau = 4;
	else
		niveau = 0;
}


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
		niveau = 5;
	else
		niveau = 0;
}

