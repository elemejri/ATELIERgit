#include <gtk/gtk.h>

void afficher_hebergements(GtkWidget *treeview);
void chercher_hebergement(GtkWidget *treeview, char *id);
