#include <string.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct date{
	int jour;
	int mois;
	int annee;
}date;

typedef struct hebergement{
	char id[20];
	char nom[20];
	char prenom[20];
	date date_entree;
	date date_sortie;
	int niveau;
	char bloc[20];
}hebergement;

void ajouter_hebergement(hebergement h);
void supprimer_hebergement(char *id);
void modifier_hebergement(hebergement h);
hebergement get_hebergement(char *id);
int nombre_etudiants_par_niveau(int niveau);
